# Sportzfy TV landing site

A responsive animated landing page for Sportzfy TV with:

- Midnight blue / cyan / magenta visual system.
- Animated star field, orbit rings and floating planets.
- Scroll reveal animations for sections and cards.
- Premium phone mockups using the supplied screenshots.
- Centered table of contents.
- Expand/collapse FAQ.
- Dynamic APK version, logo, main download URL and mirrors.
- `admin.html` configuration panel.
- Browser localStorage support plus `config.json` export.

## Files

- `index.html` — public landing page.
- `styles.css` — all visual styling and animations.
- `app.js` — config loader, screenshot carousel, reveal animations and star field.
- `config.json` — public same-domain configuration source.
- `admin.html` / `admin.js` — configuration UI.
- `assets/` — supplied Sportzfy TV logo and screenshots.

## Configuration flow

The public page first fetches `config.json` from the same domain, then overlays any locally saved browser configuration from `localStorage`.

Use `admin.html` to edit values. **Save locally** makes the change immediate for that browser. **Export config.json** creates a deployable JSON file. Replace the hosted `config.json` with the exported file to make the settings public for everyone.

A static site cannot overwrite a server-side JSON file by itself. If you later want multi-user/server persistence, connect the form to an authenticated backend endpoint that validates and writes `config.json`.

## Run locally

Serve this folder through a local HTTP server rather than opening `index.html` directly, because browsers may block `fetch()` from `file://` pages.

Example with Python:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080/`.

## Deployment

Upload the entire folder to any static host. Keep `config.json` beside `index.html` at the same domain/path. Replace the placeholder APK and mirror URLs before publishing.
